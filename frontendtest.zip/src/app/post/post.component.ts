import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AppService } from '../Service/app.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
  providers: [AppService]
})
export class PostComponent implements OnInit {
  loading = false;
  form: FormGroup;
  submitted = false;
 

  constructor(private appService: AppService, private formBuilder: FormBuilder,) { }

  ngOnInit(): void {
      this.form = this.formBuilder.group({
          userId: ['', Validators.compose([Validators.required, Validators.pattern("^[0-9]*$")])],
      title:['', [Validators.required, Validators.maxLength(40)]],
      body: ['', [Validators.required, Validators.maxLength(100)]]
    });
  
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.form.invalid) {
        return;
    }

    this.loading = true;
    this.appService.PostResources(this.form.value).subscribe(data => {
        this.loading = false;
        this.form.reset();
    })
    
  }

  get f() { 
    console.warn(this.form.controls);
    return this.form.controls; }
}
