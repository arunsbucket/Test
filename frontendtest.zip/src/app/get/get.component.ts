import { Component, OnInit } from '@angular/core';
import { AppService } from '../Service/app.service';

@Component({
  selector: 'app-get',
  templateUrl: './get.component.html',
  styleUrls: ['./get.component.css'],
  providers: [AppService]
})
export class GetComponent implements OnInit {
  obj: any;
  constructor(private appService: AppService) { }

  ngOnInit(): void {
    this.getData();
  }

  getData() {
      this.appService.GetResources().subscribe(data => {
      this.obj = data;
    })
  }
  //
}
